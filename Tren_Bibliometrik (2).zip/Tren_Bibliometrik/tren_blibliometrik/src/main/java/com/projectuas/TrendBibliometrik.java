package com.projectuas;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

public class TrendBibliometrik extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField keywordField;
    private JPanel chartPanel;

    private BibliometrikDAO dao = new BibliometrikDAO();

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                TrendBibliometrik frame = new TrendBibliometrik();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public TrendBibliometrik() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 700);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel titleLabel = new JLabel("Bibliometrik Algoritma");
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        titleLabel.setBounds(250, 10, 400, 40);
        contentPane.add(titleLabel);

        JLabel keywordLabel = new JLabel("Keyword:");
        keywordLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        keywordLabel.setBounds(30, 70, 80, 30);
        contentPane.add(keywordLabel);

        keywordField = new JTextField();
        keywordField.setFont(new Font("Tahoma", Font.PLAIN, 14));
        keywordField.setBounds(100, 70, 300, 30);
        contentPane.add(keywordField);

        JLabel yearLabel = new JLabel("Tahun:");
        yearLabel.setFont(new Font("Tahoma", Font.PLAIN, 14));
        yearLabel.setBounds(450, 70, 60, 30);
        contentPane.add(yearLabel);

        String[] years = {"2019", "2020", "2021", "2022", "2023"};
        JComboBox<String> yearComboBox = new JComboBox<>(years);
        yearComboBox.setFont(new Font("Tahoma", Font.PLAIN, 14));
        yearComboBox.setBounds(510, 70, 150, 30);
        contentPane.add(yearComboBox);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font("Tahoma", Font.BOLD, 14));
        searchButton.setBounds(700, 70, 100, 30);
        contentPane.add(searchButton);

        tableModel = new DefaultTableModel();
        tableModel.addColumn("Q1");
        tableModel.addColumn("Q2");
        tableModel.addColumn("Q3");
        tableModel.addColumn("Q4");
        tableModel.addColumn("NQ");
        tableModel.addColumn("QI");
        tableModel.addColumn("Sub Total");

        table = new JTable(tableModel);
        table.setFont(new Font("Tahoma", Font.PLAIN, 14));
        table.setRowHeight(25);
        table.setShowGrid(true);
        table.setGridColor(Color.GRAY);

        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
        renderer.setHorizontalAlignment(SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, renderer);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 130, 820, 200);
        contentPane.add(scrollPane);

        chartPanel = new JPanel();
        chartPanel.setBounds(30, 350, 820, 300);
        chartPanel.setLayout(new BorderLayout());
        contentPane.add(chartPanel);

        searchButton.addActionListener((ActionEvent e) -> {
            String keyword = keywordField.getText().trim().toLowerCase();
            int selectedYear = Integer.parseInt(yearComboBox.getSelectedItem().toString());
            displayDataForKeywordAndYear(keyword, selectedYear);
        });

        updateChart(new DefaultCategoryDataset());
    }

    private void displayDataForKeywordAndYear(String keyword, int selectedYear) {
        tableModel.setRowCount(0);

        BibliometrikDAO dao = new BibliometrikDAO();
        List<Object[]> data = dao.getBibliometrikData(keyword, selectedYear);

        if (data.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Data tidak ditemukan!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            updateChart(new DefaultCategoryDataset());
        } else {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            for (Object[] row : data) {
              
            int total = (int) row[6];
            double q1Percent = ((int) row[0] / (double) total) * 100;
            double q2Percent = ((int) row[1] / (double) total) * 100;
            double q3Percent = ((int) row[2] / (double) total) * 100;
            double q4Percent = ((int) row[3] / (double) total) * 100;

            tableModel.addRow(new Object[]{
                row[0] + " (" + String.format("%.2f", q1Percent) + "%)",
                row[1] + " (" + String.format("%.2f", q2Percent) + "%)",
                row[2] + " (" + String.format("%.2f", q3Percent) + "%)",
                row[3] + " (" + String.format("%.2f", q4Percent) + "%)",
                row[4],
                row[5],
                row[6]
            });

            dataset.addValue((int) row[0], "Q1", Integer.toString(selectedYear));
            dataset.addValue((int) row[1], "Q2", Integer.toString(selectedYear));
            dataset.addValue((int) row[2], "Q3", Integer.toString(selectedYear));
            dataset.addValue((int) row[3], "Q4", Integer.toString(selectedYear));
        }
        updateChart(dataset);
        }
    }

    private void updateChart(DefaultCategoryDataset dataset) {
        JFreeChart chart = ChartFactory.createBarChart("Trend Q1-Q4", "Tahun", "Jumlah", dataset);
        CategoryPlot plot = chart.getCategoryPlot();
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setItemMargin(0.02);

        chartPanel.removeAll();
        chartPanel.add(new ChartPanel(chart), BorderLayout.CENTER);
        chartPanel.revalidate();
    }
}
