package com.projectuas;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BibliometrikDAO {
    private Connection connection;

    
    public BibliometrikDAO() {
        try {
            String url = "jdbc:mysql://localhost:3306/TrendBibliometrikDB";
            String username = "root";
            String password = "";
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Object[]> getBibliometrikData(String keyword, int selectedYear) {
        List<Object[]> result = new ArrayList<>();
        String query = "SELECT Q1, Q2, Q3, Q4, NQ, QI, Sub_Total FROM bibliometrik WHERE Keyword = ? AND Tahun = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, keyword);
            stmt.setLong(2, selectedYear);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                result.add(new Object[]{
                    rs.getInt("Q1"),
                    rs.getInt("Q2"),
                    rs.getInt("Q3"),
                    rs.getInt("Q4"),
                    rs.getInt("NQ"),
                    rs.getInt("QI"),
                    rs.getInt("Sub_Total")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}
